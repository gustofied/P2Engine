from __future__ import annotations
from typing import List, Optional, Dict, TYPE_CHECKING
from uuid import uuid4
import pika
import json
from src.custom_logging.central_logger import central_logger  # Assuming this exists in your project
from tenacity import retry, stop_after_attempt, wait_exponential

# Type checking import for BaseAgent
if TYPE_CHECKING:
    from src.agents.base_agent import BaseAgent

class Event:
    def __init__(self, event_type: str, payload: str, correlation_id: Optional[str] = None, source: Optional[str] = None):
        """Initialize an event with type, payload, and optional tracking attributes."""
        self.type = event_type
        self.payload = payload
        self.correlation_id = correlation_id or str(uuid4())  # Unique ID for tracking async operations
        self.source = source  # Originating agent or component

    def to_dict(self) -> Dict:
        """Convert the event to a dictionary for JSON serialization."""
        return {
            "type": self.type,
            "payload": self.payload,
            "correlation_id": self.correlation_id,
            "source": self.source
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "Event":
        """Create an Event instance from a dictionary."""
        return cls(
            event_type=data["type"],
            payload=data["payload"],
            correlation_id=data.get("correlation_id"),
            source=data.get("source")
        )

class EventQueue:
    def __init__(self, session_id: str, broker_url: str = "amqp://guest:guest@localhost:5672/"):
        """Initialize the event queue with RabbitMQ for a specific session."""
        self.session_id = session_id
        self.broker_url = broker_url
        self.exchange_name = f"events_{session_id}"
        self.agent_queues: Dict[str, str] = {}  # Maps agent_id to queue_name
        self.connection = None
        self.channel = None
        self._connect()

    def _connect(self):
        """Establish a connection to RabbitMQ."""
        try:
            self.connection = pika.BlockingConnection(pika.URLParameters(self.broker_url))
            self.channel = self.connection.channel()
            self.channel.exchange_declare(exchange=self.exchange_name, exchange_type="topic", durable=True)
            central_logger.log_interaction("EventQueue", "System", f"Connected to RabbitMQ for session {self.session_id}")
        except Exception as e:
            central_logger.log_interaction("EventQueue", "System", f"Failed to connect to RabbitMQ: {str(e)}")
            raise

    def _ensure_connection(self):
        """Ensure the RabbitMQ connection and channel are active."""
        if not self.connection or self.connection.is_closed:
            self._connect()
        if not self.channel or self.channel.is_closed:
            self.channel = self.connection.channel()
            self.channel.exchange_declare(exchange=self.exchange_name, exchange_type="topic", durable=True)

    def subscribe(self, agent: "BaseAgent", event_type: str, correlation_id: Optional[str] = None):
        """Register an agent to receive events of a specific type via RabbitMQ, optionally filtered by correlation_id."""
        try:
            self._ensure_connection()
            agent_id = agent.id
            if agent_id not in self.agent_queues:
                queue_name = f"agent_{agent_id}_{self.session_id}"
                self.channel.queue_declare(queue=queue_name, durable=True, auto_delete=True)
                self.agent_queues[agent_id] = queue_name
            # Construct routing key: <event_type>.<correlation_id> if correlation_id exists, else <event_type>
            routing_key = f"{event_type}.{correlation_id}" if correlation_id else event_type
            self.channel.queue_bind(
                queue=self.agent_queues[agent_id],
                exchange=self.exchange_name,
                routing_key=routing_key
            )
            central_logger.log_interaction("EventQueue", agent.name, f"Subscribed to {routing_key}")
        except Exception as e:
            central_logger.log_interaction("EventQueue", agent.name, f"Subscription failed: {str(e)}")
            raise

    def unsubscribe(self, agent: "BaseAgent", event_type: str, correlation_id: Optional[str] = None):
        """Remove an agent's subscription to an event type, optionally filtered by correlation_id."""
        try:
            self._ensure_connection()
            agent_id = agent.id
            if agent_id in self.agent_queues:
                routing_key = f"{event_type}.{correlation_id}" if correlation_id else event_type
                self.channel.queue_unbind(
                    queue=self.agent_queues[agent_id],
                    exchange=self.exchange_name,
                    routing_key=routing_key
                )
                central_logger.log_interaction("EventQueue", agent.name, f"Unsubscribed from {routing_key}")
        except Exception as e:
            central_logger.log_interaction("EventQueue", agent.name, f"Unsubscribe failed: {str(e)}")
            raise

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    def publish(self, event: Event):
        """Publish an event to the RabbitMQ exchange with retry logic."""
        self._ensure_connection()
        routing_key = f"{event.type}.{event.correlation_id}" if event.correlation_id else event.type
        self.channel.basic_publish(
            exchange=self.exchange_name,
            routing_key=routing_key,
            body=json.dumps(event.to_dict()),
            properties=pika.BasicProperties(delivery_mode=2)  # Persistent delivery
        )

    def get_events_for_agent(self, agent: "BaseAgent") -> List["Event"]:
        """Retrieve events for a specific agent from their queue."""
        events = []
        try:
            self._ensure_connection()
            agent_id = agent.id
            if agent_id in self.agent_queues:
                queue_name = self.agent_queues[agent_id]
                while True:
                    method, _, body = self.channel.basic_get(queue=queue_name, auto_ack=False)
                    if body:
                        event_dict = json.loads(body.decode())
                        event = Event.from_dict(event_dict)
                        events.append(event)
                        self.channel.basic_ack(delivery_tag=method.delivery_tag)
                    else:
                        break
            return events
        except Exception as e:
            central_logger.log_interaction("EventQueue", agent.name, f"Failed to get events: {str(e)}")
            raise

    def close(self):
        """Close the RabbitMQ connection and channel."""
        try:
            if self.channel and not self.channel.is_closed:
                self.channel.close()
            if self.connection and not self.connection.is_closed:
                self.connection.close()
            central_logger.log_interaction("EventQueue", "System", "Closed RabbitMQ connection")
        except Exception as e:
            central_logger.log_interaction("EventQueue", "System", f"Failed to close connection: {str(e)}")