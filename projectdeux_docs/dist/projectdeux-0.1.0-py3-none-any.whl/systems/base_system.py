from abc import ABC, abstractmethod
from typing import List, Dict, Optional
import uuid
from src.agents.base_agent import BaseAgent
from src.entities.entity_manager import EntityManager
from src.entities.component_manager import ComponentManager
from src.custom_logging.central_logger import central_logger
from src.tasks.task_manager import TaskManager
from src.tasks.async_task_manager import AsyncTaskManager
from src.systems.event_system import EventQueue
from src.agents.factory import AgentFactory
from src.states.state_registry import StateRegistry
from src.integrations.artifact_store import ArtifactStore
from celery_app import BROKER_URL

class BaseSystem(ABC):
    session_instances = {}

    def __init__(
        self,
        agents: List[BaseAgent],
        entity_manager: EntityManager,
        component_manager: ComponentManager,
        config: Dict,
        run_id: Optional[str] = None,
        task_manager: Optional[TaskManager] = None,
        config_path: str = "scenario.yaml"
    ):
        self.id = run_id or str(uuid.uuid4())
        self.run_id = self.id
        self.agents = agents
        self.entity_manager = entity_manager
        self.component_manager = component_manager
        self.config = config
        self.task_manager = task_manager or TaskManager()
        self.async_task_manager = AsyncTaskManager()
        self.logger = central_logger
        self.event_queue = EventQueue(session_id=self.id, broker_url=BROKER_URL)
        self.config_path = config_path
        self.state_registry = StateRegistry(config_path)
        self.artifact_store = ArtifactStore(storage_file=f"artifacts_{self.id}.json")

        self.goal = config.get('goal', 'No goal specified')
        self.expected_result = config.get('expected_result', 'No expected result specified')

        for agent in self.agents:
            agent.session = self
            agent.state_registry = self.state_registry

        BaseSystem.session_instances[self.id] = self

    def spawn_agent(self, agent_type: str, parent: "BaseAgent" = None, correlation_id: str = None):
        """Spawn a new agent using AgentFactory with StateRegistry."""
        config = {
            "name": f"{agent_type}_{uuid.uuid4()}",
            "system_prompt": f"Agent type: {agent_type}",
            "role": agent_type
        }
        agent = AgentFactory.create_agent(
            entity_manager=self.entity_manager,
            component_manager=self.component_manager,
            config=config,
            session=self,
            state_registry=self.state_registry
        )
        agent.parent = parent
        agent.correlation_id = correlation_id
        self.agents.append(agent)
        self.logger.log_interaction("System", agent.name, f"Spawned as sub-agent of {parent.name if parent else 'None'}")
        return agent

    def tick(self):
        """Simulate one cycle of the event loop by fetching and processing events for each agent."""
        for agent in self.agents:
            events = self.event_queue.get_events_for_agent(agent)
            for event in events:
                agent.process_event(event)
            agent.step()

    def __del__(self):
        """Clean up the event queue connection when the system is destroyed."""
        self.event_queue.close()

    def get_agent_by_name(self, agent_name):
        try:
            if isinstance(self.agents, dict):
                return self.agents.get(agent_name)
            return next(agent for agent in self.agents if agent.name == agent_name)
        except (StopIteration, AttributeError):
            return None

    def get_all_agents(self):
        if isinstance(self.agents, dict):
            return list(self.agents.values())
        return self.agents

    @abstractmethod
    def define_workflow(self) -> List[Dict]:
        pass

    def log_start(self, problem: str):
        self.logger.log_system_start(
            system_name=self.__class__.__name__,
            entities=self.entity_manager.entities,
            problem=problem,
            goal=self.goal,
            expected_result=self.expected_result
        )

    def log_end(self, result: str, metadata: Dict, score: int):
        all_agents = self.get_all_agents()
        self.logger.log_system_end(result, metadata, score, all_agents)

    def build_workflow_from_sequence(self, task_sequence: List[Dict]) -> List[Dict]:
        from src.tasks.task_registry import TASK_REGISTRY

        workflow = []
        scenario_data = {
            "goal": self.goal,
            "problem": self.config.get("problem", "No problem defined"),
            "system_prompts": {agent.name: agent.system_prompt for agent in self.get_all_agents()},
            "agent_names": {agent.id: agent.name for agent in self.get_all_agents()},
            "run_params": self.config.get("run_params", {}),
            "context": {}
        }

        for i, task_config in enumerate(task_sequence):
            agent = self.get_agent_by_name(task_config["agent_name"])
            if agent:
                task_func = TASK_REGISTRY["generic_task"]["function"]
                queue = task_config.get("queue", "default")
                if i == 0:
                    args = [None, agent.system_prompt, task_config, scenario_data]
                else:
                    args = [agent.system_prompt, task_config, scenario_data]
                workflow.append({
                    "task_func": task_func,
                    "args": args,
                    "queue": queue,
                    "task_config": task_config
                })
            else:
                self.logger.warning(f"Agent '{task_config['agent_name']}' not found")
        return workflow

    def run_workflow(self, workflow: List[Dict]) -> Dict:
        if self.config.get("execution_type") == "asynchronous":
            from celery import chain
            celery_tasks = []
            for task in workflow:
                task_func = task["task_func"]
                args = task["args"]
                queue = task["queue"]
                celery_task = task_func.s(*args).set(queue=queue)
                celery_tasks.append(celery_task)
            full_chain = chain(*celery_tasks)
            async_result = full_chain()
            final_result = self.async_task_manager.get_task_result(async_result, timeout=120)
            result, scenario_data = final_result[:2]
            logs = final_result[2] if len(final_result) > 2 else []
            for log in logs:
                self.logger.log_interaction(sender=log["from"], receiver=log["to"], message=log["message"])
            return {"final_result": result, "scenario_data": scenario_data, "logs": logs}
        elif self.config.get("execution_type") == "synchronous":
            results = {}
            previous_output = None
            for i, task in enumerate(workflow):
                task_func = task["task_func"]
                task_config = task["task_config"]
                agent = self.get_agent_by_name(task_config["agent_name"])
                if i == 0:
                    args = task["args"]
                else:
                    scenario_data = previous_output[1]
                    args = [previous_output, agent.system_prompt, task_config, scenario_data]
                previous_output = task_func(*args)
                result, scenario_data = previous_output
                results[task_config["task_name"]] = result
            return {"final_result": results, "scenario_data": scenario_data, "logs": []}
        else:
            raise ValueError(f"Invalid execution type: {self.config.get('execution_type')}")
    
    def run(self, **kwargs):
        self.log_start(kwargs.get("problem", "Unnamed problem"))
        workflow = self.define_workflow()
        built_workflow = self.build_workflow_from_sequence(workflow)
        results = self.run_workflow(built_workflow)
        self.log_end(str(results["final_result"]), metadata={"tasks": len(workflow)}, score=100)
        return results