from .base_tool import Tool
from ..artifact_store import ArtifactStore

class MemoryWriteTool(Tool):
    def __init__(self):
        self.artifact_store = None

    def set_artifact_store(self, artifact_store: ArtifactStore):
        self.artifact_store = artifact_store

    def execute(self, key: str, value: str) -> str:
        if self.artifact_store is None:
            raise ValueError("ArtifactStore not set")
        self.artifact_store.write(key, value)
        return f"Stored '{key}' in artifact store."

class MemoryLookupTool(Tool):
    def __init__(self):
        self.artifact_store = None

    def set_artifact_store(self, artifact_store: ArtifactStore):
        self.artifact_store = artifact_store

    def execute(self, key: str) -> str:
        if self.artifact_store is None:
            raise ValueError("ArtifactStore not set")
        value = self.artifact_store.read(key)
        if value is not None:
            return f"Value for '{key}': {value}"
        return f"No value found for '{key}'"