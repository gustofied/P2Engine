import json
import os
from typing import Any
from src.tasks.task_registry import write_artifact
from src.custom_logging.central_logger import central_logger

class ArtifactStore:
    def __init__(self, storage_file: str = "artifacts.json"):
        self.store = {}
        self.storage_file = storage_file
        self._load_from_file()

    def _load_from_file(self):
        if os.path.exists(self.storage_file):
            try:
                with open(self.storage_file, 'r') as f:
                    self.store = json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                print(f"Failed to load artifacts from {self.storage_file}: {e}")
                self.store = {}

    def write(self, key: str, value: Any) -> None:
        self.store[key] = value
        write_artifact.apply_async(args=(self.storage_file, key, value), queue="artifact_write")
        central_logger.log_interaction("ArtifactStore", "System", f"Queued write for key '{key}'")

    def read(self, key: str) -> Any:
        return self.store.get(key)