import json
from typing import List, Dict, Optional
import uuid
from src.systems.base_system import BaseSystem
from src.entities.entity_manager import EntityManager
from src.entities.component_manager import ComponentManager
from src.tasks.task_manager import TaskManager
from src.custom_logging.central_logger import central_logger
from src.states.state_registry import StateRegistry
from src.agents.base_agent import BaseAgent
from src.redis_client import redis_client
from src.event import Event

class GenericSystem(BaseSystem):
    def __init__(
        self,
        config_path: str,
        entity_manager: EntityManager,
        component_manager: ComponentManager,
        config: Dict,
        run_id: str,
        task_manager: Optional[TaskManager] = None
    ):
        super().__init__(
            agents=[],
            entity_manager=entity_manager,
            component_manager=component_manager,
            config=config,
            run_id=run_id,
            task_manager=task_manager,
            config_path=config_path
        )
        self.subscribe(self, "SpawnAgentEvent")

    def handle_event(self, event: Event):
        if event.type == "SpawnAgentEvent":
            data = event.payload
            sub_agent_name = data["agent_name"]
            task = data["task"]
            parent_id = data.get("parent_id")
            correlation_id = data.get("correlation_id")
            sub_agent = self.spawn_agent(sub_agent_name)
            sub_agent.parent = self.entity_manager.get_entity(parent_id) if parent_id else None
            sub_agent.correlation_id = correlation_id
            self.publish(Event("UserMessageEvent", task))
            central_logger.log_interaction(
                "System", "System", f"Spawned sub-agent {sub_agent_name} with task: {task}", self.run_id
            )

    def spawn_agent(self, name: str) -> BaseAgent:
        agent = BaseAgent(
            entity_manager=self.entity_manager,
            component_manager=self.component_manager,
            name=name,
            state_registry=self.state_registry,
            session=self,
            run_id=self.run_id
        )
        self.agents.append(agent)
        config = {
            "name": agent.name,
            "model": getattr(agent, "model_name", "default_model"),
            "system_prompt": getattr(agent, "system_prompt", "default_prompt"),
            "tools": [tool.__class__.__name__ for tool in getattr(agent, "tools", [])]
        }
        redis_client.set(f"agent_config:{agent.id}", json.dumps(config))
        return agent

    def define_workflow(self) -> List[Dict]:
        task_sequence = self.config.get("task_sequence", [])
        if self.config.get("execution_type") == "asynchronous":
            for task in task_sequence:
                base_queue = task.get("queue", "default")
                task["queue"] = f"{base_queue}_{self.run_id}"
        return task_sequence

    def branch(self, agent: BaseAgent, branches: List[Dict]) -> List[BaseAgent]:
        correlation_id = str(uuid.uuid4())
        sub_agents = []
        for branch in branches:
            sub_agent_name = branch.get("agent_name", f"SubAgent_{len(self.agents)}")
            event = Event("SpawnAgentEvent", {
                "agent_name": sub_agent_name,
                "task": branch.get("task", "Default task"),
                "parent_id": agent.id,
                "correlation_id": correlation_id
            })
            self.publish(event)
            sub_agent = next((a for a in self.agents if a.name == sub_agent_name), None)
            if sub_agent:
                sub_agents.append(sub_agent)
        self.subscribe(agent, "AgentResultEvent", correlation_id)
        central_logger.log_interaction(
            agent.name, "System", f"Spawned sub-agents: {[a.name for a in sub_agents]}", self.run_id
        )
        return sub_agents