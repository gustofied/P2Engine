import json
from typing import Any
from src.redis_client import redis_client
from src.custom_logging.central_logger import central_logger

class ArtifactStore:
    def __init__(self):
        """Initialize the ArtifactStore with a Redis client."""
        self.redis_client = redis_client

    def write(self, key: str, value: Any, run_id: str) -> None:
        """Write a key-value pair to Redis with run_id context."""
        serialized_value = json.dumps(value)
        self.redis_client.set(key, serialized_value)
        central_logger.log_interaction("ArtifactStore", "System", f"Wrote key '{key}' to Redis", run_id)

    def read(self, key: str) -> Any:
        """Read a value from Redis by key."""
        value = self.redis_client.get(key)
        if value:
            return json.loads(value)
        return None