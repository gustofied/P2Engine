from celery import shared_task
from src.entities.entity_manager import EntityManager
from src.entities.component_manager import ComponentManager
from src.custom_logging.central_logger import central_logger
from typing import TYPE_CHECKING, Any
import json
import os

if TYPE_CHECKING:
    from src.agents.base_agent import BaseAgent

def resolve_param(param_value, scenario_data):
    """Resolve parameter values from run_params or context, handling non-string values."""
    if not isinstance(param_value, str):
        return param_value
    if param_value.startswith("run_params."):
        key = param_value.split(".", 1)[1]
        return scenario_data.get("run_params", {}).get(key, "")
    elif param_value.startswith("context."):
        keys = param_value.split(".")[1:]
        value = scenario_data.get("context", {})
        for key in keys:
            value = value.get(key, {})
        if isinstance(value, list):
            outputs = [item["output"] for item in value if "output" in item]
            return ", ".join(outputs)
        return str(value)
    return param_value

@shared_task
def generic_task(previous_output, agent_system_prompt, task_config, scenario_data=None):
    """
    Generic task that executes any instruction based on task_config.
    """
    task_name = task_config["task_name"]
    instruction = task_config["instruction"]
    params_config = task_config.get("params", {})

    if previous_output is None:
        scenario_data = scenario_data or {"context": {}, "run_params": {}, "run_id": "unknown_run_id"}
    else:
        _, scenario_data = previous_output

    from src.agents.base_agent import BaseAgent
    from src.states.state_registry import StateRegistry

    entity_manager = EntityManager()
    component_manager = ComponentManager()
    state_registry = StateRegistry()
    agent = BaseAgent(
        entity_manager=entity_manager,
        component_manager=component_manager,
        name=task_config.get("agent_name", "TempAgent"),
        state_registry=state_registry,
        system_prompt=agent_system_prompt
    )

    params = {k: resolve_param(v, scenario_data) for k, v in params_config.items()}
    user_input = instruction.format(**params)

    result = agent.interact(user_input)

    scenario_data["context"].setdefault(task_name, []).append({"agent": agent.name, "output": result})
    # Updated to use run_id from scenario_data
    central_logger.log_interaction("System", agent.name, f"Executed {task_name}: {result}", scenario_data.get("run_id", "unknown_run_id"))

    return (result, scenario_data)

@shared_task
def write_artifact(storage_file: str, key: str, value: Any) -> None:
    """Write a key-value pair to a JSON artifact file."""
    try:
        if os.path.exists(storage_file):
            with open(storage_file, 'r') as f:
                store = json.load(f)
        else:
            store = {}
        store[key] = value
        with open(storage_file, 'w') as f:
            json.dump(store, f, indent=2)
        # Updated with placeholder run_id (consider passing run_id if possible)
        central_logger.log_interaction("ArtifactWriteTask", "System", f"Wrote key '{key}' to {storage_file}", "unknown_run_id")
    except Exception as e:
        # Updated with placeholder run_id (consider passing run_id if possible)
        central_logger.log_interaction("ArtifactWriteTask", "System", f"Failed to write key '{key}' to {storage_file}: {str(e)}", "unknown_run_id")

from src.tasks.task_definitions import process_agent_step, process_branch_task

TASK_REGISTRY = {
    "generic_task": {"function": generic_task},
    "write_artifact": {"function": write_artifact},
    "process_agent_step": {"function": process_agent_step},
    "process_branch_task": {"function": process_branch_task},
}