from celery_app import app
from src.custom_logging.central_logger import central_logger
from src.redis_client import redis_client
from src.agents.factory import AgentFactory
from src.event import Event
from celery_app import BROKER_URL
import json
from redis.exceptions import LockError

@app.task
def process_agent_step(agent_id: str, session_id: str, run_id: str):
    """Process a step for an agent using Redis for state management and concurrency protection."""
    lock = redis_client.lock(f"agent_lock:{agent_id}", timeout=30)
    try:
        lock.acquire(blocking=True, blocking_timeout=5)
        config_str = redis_client.get(f"agent_config:{agent_id}")
        if not config_str:
            central_logger.log_interaction("Celery", "System", f"Agent config for {agent_id} not found", run_id)
            return
        config = json.loads(config_str)

        from src.entities.entity_manager import EntityManager
        from src.entities.component_manager import ComponentManager
        from src.states.state_registry import StateRegistry

        entity_manager = EntityManager()
        component_manager = ComponentManager()
        try:
            state_registry = StateRegistry("src/config/scenario.yaml")
        except FileNotFoundError:
            state_registry = StateRegistry()

        agent = AgentFactory.create_agent(
            entity_manager=entity_manager,
            component_manager=component_manager,
            config=config,
            state_registry=state_registry,
            run_id=run_id
        )
        agent.id = agent_id

        agent.load_state()
        central_logger.log_interaction("Celery", agent.name, "Loaded state", run_id)

        agent.step()

        agent.save_state()
        central_logger.log_interaction("Celery", agent.name, "Saved state", run_id)

        central_logger.log_interaction("Celery", agent.name, "Processed step (no events fetched)", run_id)
    finally:
        try:
            lock.release()
        except LockError:
            pass

@app.task
def process_branch_task(agent_id: str, session_id: str, task: str, correlation_id: str, run_id: str):
    """Process a branch task for an agent in a given session."""
    from src.systems.base_system import BaseSystem
    session = BaseSystem.session_instances.get(session_id)
    if not session:
        central_logger.log_interaction("Celery", "System", f"Session {session_id} not found", run_id)
        return
    agent = next((a for a in session.agents if a.id == agent_id), None)
    if not agent:
        central_logger.log_interaction("Celery", "System", f"Agent {agent_id} not found", run_id)
        return
    event = Event("UserMessageEvent", task, correlation_id)
    session.publish(event)
    agent.process_event(event)
    agent.step()