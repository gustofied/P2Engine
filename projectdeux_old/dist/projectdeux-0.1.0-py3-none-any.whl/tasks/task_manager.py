from typing import List, Dict, Optional
import uuid
from src.agents.base_agent import BaseAgent
from src.states.base import AssistantMessage
from src.custom_logging.central_logger import central_logger
from src.event import Event

class TaskManager:
    def __init__(self):
        self.tasks: Dict[str, Dict] = {}
        self.task_states: Dict[str, str] = {}
        self.task_results: Dict[str, str] = {}

    def register_task(self, task_name: str, agents: List[BaseAgent], instruction: str, 
                      dependencies: List[str] = None, required_params: List[str] = None,
                      dependency_params: Dict[str, str] = None):
        self.tasks[task_name] = {
            "agents": agents,
            "instruction": instruction,
            "dependencies": dependencies or [],
            "required_params": required_params or [],
            "dependency_params": dependency_params or {}
        }
        self.task_states[task_name] = "pending"

    def execute_task(self, task_name: str, **kwargs):
        if task_name in self.task_results:
            return self.task_results[task_name]

        task = self.tasks.get(task_name)
        if not task:
            raise ValueError(f"Task '{task_name}' not found")

        self.task_states[task_name] = "active"

        dependency_outputs = {}
        for dep in task["dependencies"]:
            dep_task = self.tasks.get(dep)
            if not dep_task:
                raise ValueError(f"Dependency '{dep}' not found")
            dep_kwargs = {k: v for k, v in kwargs.items() if k in dep_task["required_params"]}
            response = self.execute_task(dep, **dep_kwargs)
            param_name = task["dependency_params"].get(dep, dep)
            dependency_outputs[param_name] = response

        task_kwargs = {**kwargs, **dependency_outputs}
        missing_params = [param for param in task["required_params"] if param not in task_kwargs]
        if missing_params:
            raise ValueError(f"Missing parameters for '{task_name}': {missing_params}")

        instruction = task["instruction"].format(**task_kwargs)

        if len(task["agents"]) == 1:
            agent = task["agents"][0]
            if agent.session:
                event = Event(type="UserMessageEvent", payload=instruction, correlation_id=str(uuid.uuid4()))
                agent.session.publish(event)
                # For synchronous execution in this context
                agent.process_event(event)
                agent.step()
                for state in reversed(agent.interaction_stack):
                    if isinstance(state, AssistantMessage):
                        response = state.response
                        break
                else:
                    response = "No response generated"
            else:
                response = agent.interact(instruction)
        else:
            responses = [agent.interact(instruction) for agent in task["agents"]]
            response = self.coordinate_responses(responses, task_name)

        self.task_states[task_name] = "completed"
        self.task_results[task_name] = response
        return response

    def coordinate_responses(self, responses: List[str], task_name: str) -> str:
        valid_responses = [r.strip() for r in responses if r.strip()]
        if not valid_responses:
            return f"All agents returned empty responses for task '{task_name}'."
        summary = f"Coordinated Responses for '{task_name}':\n"
        for i, response in enumerate(valid_responses, 1):
            preview = response[:100] + ("..." if len(response) > 100 else "")
            summary += f"- Agent {i}: {preview}\n"
        return summary

    def get_task_state(self, task_name: str) -> Optional[str]:
        return self.task_states.get(task_name)