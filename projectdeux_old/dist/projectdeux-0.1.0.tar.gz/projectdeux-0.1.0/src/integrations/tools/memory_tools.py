from .base_tool import Tool
from typing import Optional

class MemoryWriteTool(Tool):
    def __init__(self):
        self.artifact_store = None

    def set_artifact_store(self, artifact_store):
        self.artifact_store = artifact_store

    def execute(self, key: str, value: str, run_id: Optional[str] = None) -> str:
        if self.artifact_store is None:
            from ..artifact_store import ArtifactStore
            self.artifact_store = ArtifactStore()
        run_id = run_id or "no_session"  # Fallback if not provided
        self.artifact_store.write(key, value, run_id)
        return f"Stored '{key}' in artifact store."

class MemoryLookupTool(Tool):
    def __init__(self):
        self.artifact_store = None

    def set_artifact_store(self, artifact_store):
        self.artifact_store = artifact_store

    def execute(self, key: str) -> str:
        if self.artifact_store is None:
            from ..artifact_store import ArtifactStore
            self.artifact_store = ArtifactStore()
        value = self.artifact_store.read(key)
        if value is not None:
            return f"Value for '{key}': {value}"
        return f"No value found for '{key}'"