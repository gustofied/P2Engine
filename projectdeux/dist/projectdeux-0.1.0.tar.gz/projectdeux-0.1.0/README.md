## Adam Dybwad Sioud
