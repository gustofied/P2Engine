import os
import json
import datetime

def my_custom_logging_fn(model_call_dict: dict) -> None:
    """
    Custom logging function for litellm API calls.
    
    Appends a timestamp to the logging payload and writes it as a JSON line
    into a log file in the logs/ directory.
    """
    # Add a timestamp to the payload
    model_call_dict["timestamp"] = datetime.datetime.now().isoformat()
    
    # Ensure the logs directory exists
    log_dir = "logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # Define the log file path
    log_file = os.path.join(log_dir, "litellm_log.json")
    
    # Append the JSON payload as a new line
    with open(log_file, "a") as f:
        json.dump(model_call_dict, f)
        f.write("\n")
    
    # Optionally, print a confirmation
    print("Logged litellm call details:", model_call_dict)
