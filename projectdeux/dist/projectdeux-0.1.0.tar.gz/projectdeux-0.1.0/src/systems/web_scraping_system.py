# projectdeux/src/systems/web_scraping_system.py
from .base_system import BaseSystem

class WebScrapingSystem(BaseSystem):
    def run(self, problem: str = "Web scraping task", **kwargs):
        self.log_start(problem)
        results = {}
        run_params = self.config.get("run_params", {})
        urls = kwargs.get("urls", run_params.get("urls", []))
        target = kwargs.get("target", run_params.get("target", "p"))
        goal = kwargs.get("goal", self.config.get("goal", "Summarize the content"))

        for url in urls:
            # Asynchronously queue the "scrape" task
            queued_info = self.task_manager.execute_task("scrape", url=url, target=target)
            results[url] = queued_info

        final_result_md = f"# Scraping Results for {problem}\n\n"
        for url, info in results.items():
            final_result_md += f"**{url}** => {info}\n\n"

        # "summarize" task can also be queued if you want:
        # e.g. self.task_manager.execute_task("summarize", text="...some text...")

        self.log_end(final_result_md, {"success": True}, 10)
        return final_result_md
