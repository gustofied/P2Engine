from .base_agent import BaseAgent

class LogAnalyzerAgent(BaseAgent):
    def __init__(self, entity_manager, component_manager, name="LogAnalyzer", model="deepseek/deepseek-chat", api_key=None):
        """
        Initialize the LogAnalyzerAgent with a system prompt for HTML generation.
        
        Args:
            entity_manager: Manager for entity data
            component_manager: Manager for component data
            name: Name of the agent (default: "LogAnalyzer")
            model: Model to use for analysis (default: "deepseek/deepseek-chat")
            api_key: API key for the model (default: None)
        """
        system_prompt = (
            "You are a log analysis specialist. Your task is to analyze a system log and produce an HTML snippet "
            "summarizing the system's execution. The summary should be clear and concise, including the system name, "
            "goal, key interactions, result, and time spent. Use simple HTML with inline CSS for styling (e.g., "
            "<h2>, <p>, <ul>, <li>) and ensure the output fits within a <div class='playground-llm'></div>. "
            "Return only the HTML code, with no additional text or comments."
        )
        super().__init__(
            entity_manager=entity_manager,
            component_manager=component_manager,
            name=name,
            model=model,
            api_key=api_key,
            system_prompt=system_prompt
        )