from .entity import Entity
import json

class Component:
    def __init__(self, name):
        self.name = name

class ToolComponent(Component):
    def __init__(self, tool_name):
        super().__init__("tool")
        self.tool_name = tool_name

class ConnectionComponent(Component):
    def __init__(self, target_entity_id):
        super().__init__("connection")
        self.target_entity_id = target_entity_id

class MemoryComponent(Component):
    def __init__(self):
        super().__init__("memory")
        self.history = []

    def add_to_history(self, message):
        self.history.append(message)

class ComponentManager:
    def __init__(self, config_path: str = None):
        # Default component types
        self.component_types = {
            "tool": ToolComponent,
            "connection": ConnectionComponent,
            "memory": MemoryComponent
        }
        # Load additional components from config file if provided
        if config_path:
            try:
                with open(config_path, "r") as f:
                    config = json.load(f)
                for name, class_path in config.get("components", {}).items():
                    module_name, class_name = class_path.rsplit(".", 1)
                    module = __import__(module_name, fromlist=[class_name])
                    self.component_types[name] = getattr(module, class_name)
            except Exception as e:
                print(f"Failed to load component config: {e}")

    def create_component(self, component_type: str, **kwargs):
        component_class = self.component_types.get(component_type)
        if component_class:
            return component_class(**kwargs)
        raise ValueError(f"Unknown component type: {component_type}")

    def attach_component(self, entity: Entity, component_type: str, **kwargs):
        component = self.create_component(component_type, **kwargs)
        entity.add_component(component.name, component)