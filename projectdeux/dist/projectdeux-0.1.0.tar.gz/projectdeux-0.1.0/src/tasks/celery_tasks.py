# projectdeux/src/tasks/celery_tasks.py

from projectdeux.celery_app import app
from custom_logging.central_logger import central_logger

# Tools/LLMs from your existing code
from integrations.tools.web_scraper_tool import WebScraperTool
from integrations.llm.llm_client import LLMClient

#######################################
# SCRAPING TASKS
#######################################
@app.task
def scrape_task(url: str, target: str = "p"):
    """
    Asynchronously scrape a webpage using WebScraperTool.
    Returns the scraped text or an error message.
    """
    central_logger.log_interaction("CeleryTask", "System", f"Scraping {url} (target={target})")
    scraper = WebScraperTool()
    content = scraper.execute(url, target)
    return content


#######################################
# ANALYSIS TASKS
#######################################
@app.task
def analyze_task(text: str, model: str = "github/gpt-4o"):
    """
    Analyze text using an LLM.
    """
    central_logger.log_interaction("CeleryTask", "System", f"Analyzing text length = {len(text)}")
    llm_client = LLMClient(model=model)
    messages = [
        {"role": "system", "content": "You are an analysis assistant."},
        {"role": "user", "content": text}
    ]
    analysis_result = llm_client.query(messages)
    return analysis_result


#######################################
# SUMMARIZE TASKS
#######################################
@app.task
def summarize_task(text: str):
    """
    Summarize text with a simple logic or an LLM.
    For brevity, here's a naive approach.
    """
    central_logger.log_interaction("CeleryTask", "System", f"Summarizing text length = {len(text)}")
    # Just a placeholder approach:
    if len(text) > 200:
        return text[:200] + "...(truncated)"
    return text
