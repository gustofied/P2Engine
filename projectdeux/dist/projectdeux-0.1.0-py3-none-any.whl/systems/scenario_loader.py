# projectdeux/src/systems/scenario_loader.py
from src.systems.research_system import ResearchSystem
from src.systems.web_scraping_system import WebScrapingSystem
from tasks.celery_task_manager import CeleryTaskManager
from src.entities.entity_manager import EntityManager
from src.entities.component_manager import ComponentManager

SYSTEM_REGISTRY = {
    "web_scraping": WebScrapingSystem,
    "research_system": ResearchSystem
}

def load_system(config: dict):
    system_type = config["system_type"]
    system_class = SYSTEM_REGISTRY.get(system_type)
    if not system_class:
        raise ValueError(f"Unknown system type '{system_type}'")

    # Optionally create a CeleryTaskManager instead of a normal TaskManager
    task_manager = CeleryTaskManager()

    # Entities/Components if you still use them:
    entity_manager = EntityManager()
    component_manager = ComponentManager()

    # Create the system instance
    system = system_class(
        agents=[],  # or create them from config if you want
        entity_manager=entity_manager,
        component_manager=component_manager,
        config=config,
        task_manager=task_manager
    )
    return system
