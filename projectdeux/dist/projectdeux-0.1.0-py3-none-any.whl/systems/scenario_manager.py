# projectdeux/src/systems/scenario_manager.py

import os
import yaml

class ScenarioManager:
    def __init__(self, scenarios_dir: str):
        """
        Loads scenario YAML files from the given directory.
        Each file can define one or more 'scenarios' in an array.
        """
        self.scenarios = {}
        if not os.path.isdir(scenarios_dir):
            raise ValueError(f"'{scenarios_dir}' is not a directory")

        for filename in os.listdir(scenarios_dir):
            if filename.endswith(".yaml") or filename.endswith(".yml"):
                file_path = os.path.join(scenarios_dir, filename)
                with open(file_path, "r") as file:
                    config = yaml.safe_load(file) or {}
                    # Each file can have "scenarios" as a list
                    for scenario in config.get("scenarios", []):
                        scenario_name = scenario.get("name", "unnamed_scenario")
                        self.scenarios[scenario_name] = scenario

    def get_scenario(self, name: str):
        if name not in self.scenarios:
            raise ValueError(f"Scenario '{name}' not found.")
        return self.scenarios[name]

    def list_scenarios(self):
        return list(self.scenarios.keys())
