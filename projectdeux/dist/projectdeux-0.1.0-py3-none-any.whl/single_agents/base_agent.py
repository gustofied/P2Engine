from abc import abstractmethod
from entities.smart_entity import SmartEntity
from integrations.llm.llm_client import LLMClient
from custom_logging.litellm_logger import my_custom_logging_fn

class BaseAgent(SmartEntity):
    def __init__(self, name: str, model: str = "gpt-3.5-turbo", api_key: str = None, tools=None):
        super().__init__(entity_type="agent", name=name)
        self.model = model
        self.api_key = api_key  # If None, LLMClient will read from environment.
        self.tools = tools or []

        self.llm = LLMClient(
            model=self.model,
            api_key=self.api_key, 
            logger_fn=my_custom_logging_fn
        )

    @abstractmethod
    def interact(self, user_input: str) -> str:
        """
        Process user input and return a response.
        """
        pass
