from dotenv import load_dotenv
load_dotenv()  # Loads environment variables from .env file

from integrations.llm.llm_client import LLMClient
from logging.litellm_logger import my_custom_logging_fn
from single_agents.base_agent import BaseAgent  # assuming you have a BaseAgent defined

class SimpleAgent(BaseAgent):
    def __init__(self, model: str = "gpt-3.5-turbo", api_key: str = None):
        # Initialize LLMClient with our custom logger function
        self.llm = LLMClient(model=model, api_key=api_key, logger_fn=my_custom_logging_fn)

    def interact(self, user_input: str) -> str:
        response = self.llm.query(user_input)
        return f"SimpleAgent: {response}"

if __name__ == "__main__":
    agent = SimpleAgent()  # API key will be loaded from the environment variable OPENAI_APY_KEY
    print(agent.interact("Tell me a joke."))
