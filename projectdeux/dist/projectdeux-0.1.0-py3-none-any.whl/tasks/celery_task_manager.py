# projectdeux/src/tasks/celery_task_manager.py

from .celery_tasks import scrape_task, analyze_task, summarize_task
from custom_logging.central_logger import central_logger
from celery.result import AsyncResult
from projectdeux.celery_app import app

class CeleryTaskManager:
    """
    Manages registration and asynchronous execution of tasks using Celery.
    """

    def __init__(self):
        # You could store metadata about tasks here if needed
        self.tasks = {}
        self.task_states = {}  # optional local tracking

    def register_task(self, task_name: str, description: str = "", **kwargs):
        """
        Optionally store metadata about tasks (like dependencies, etc.).
        """
        self.tasks[task_name] = {
            "description": description,
            "kwargs": kwargs
        }
        self.task_states[task_name] = "registered"

    def execute_task(self, task_name: str, **kwargs) -> str:
        """
        Dispatch the named task to Celery with the provided kwargs.
        Returns a string referencing the queued task ID.
        """
        if task_name == "scrape":
            result_async = scrape_task.delay(kwargs["url"], kwargs.get("target", "p"))
            self.task_states[task_name] = "queued"
            central_logger.log_interaction("CeleryTaskManager", "System", f"Scrape queued. ID={result_async.id}")
            return f"ScrapeTask queued (ID={result_async.id})"

        elif task_name == "analyze":
            text = kwargs["text"]
            model = kwargs.get("model", "github/gpt-4o")
            result_async = analyze_task.delay(text, model)
            self.task_states[task_name] = "queued"
            central_logger.log_interaction("CeleryTaskManager", "System", f"Analyze queued. ID={result_async.id}")
            return f"AnalyzeTask queued (ID={result_async.id})"

        elif task_name == "summarize":
            text = kwargs["text"]
            result_async = summarize_task.delay(text)
            self.task_states[task_name] = "queued"
            central_logger.log_interaction("CeleryTaskManager", "System", f"Summarize queued. ID={result_async.id}")
            return f"SummarizeTask queued (ID={result_async.id})"

        else:
            # If you have more tasks, add them or raise an error
            return f"Unknown task: {task_name}"

    def get_task_result(self, task_id: str):
        """
        If you want to check the status or result of a Celery task, do so here.
        """
        async_res = AsyncResult(task_id, app=app)
        if async_res.ready():
            return async_res.result
        return f"Task {task_id} not finished yet. Current status: {async_res.status}"
